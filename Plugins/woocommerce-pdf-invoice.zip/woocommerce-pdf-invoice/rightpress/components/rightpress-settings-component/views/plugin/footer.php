<?php

// Exit if accessed directly
defined('ABSPATH') || exit;

/**
 * Settings page footer view
 */

?>


