<?php
/**
 * SCREETS © 2024
 *
 * SCREETS, d.o.o. Sarajevo. All rights reserved.
 * This  is  commercial  software,  only  users  who have purchased a valid
 * license  and  accept  to the terms of the  License Agreement can install
 * and use this program.
 *
 * 
 * 
 *  "Peace at home, peace in the world."
 *      - M. Kemal Atatürk (1881-193∞)
 */
