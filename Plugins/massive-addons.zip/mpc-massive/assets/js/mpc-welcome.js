( function( $ ) {
	"use strict";

	$( '.button-next' ).on( 'click', function() {
		$( '.ma-setup-content' ).addClass( 'block-content' );
	} );
})( jQuery );