<?php
/**
 * Messages for a typography tab.
 */

?>

<div class="wpb_message_placeholder notice notice-success "><p></p></div>
<div class="wpb_message_placeholder notice notice-error "><p></p></div>
