<?php
/**
 * SEO analysis tab template.
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
?>

<div id="vc_ui-seo-analysis" class="vc_ui-seo-panel">
	<div class="vc_ui-helper-preloader">
		<div class="vc_ui-wp-spinner vc_ui-wp-spinner-dark vc_ui-wp-spinner-lg"></div>
	</div>
</div>
