<?php
/**
 * Class that handles specific [vc_posts_slider] shortcode
 *
 * @see js_composer/include/templates/shortcodes/vc_posts_slider.php
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Class WPBakeryShortCode_Vc_Posts_slider
 */
class WPBakeryShortCode_Vc_Posts_Slider extends WPBakeryShortCode {
}
