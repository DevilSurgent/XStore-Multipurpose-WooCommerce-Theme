<?php
/**
 * Class that handles specific [vc_zigzag] shortcode.
 *
 * @see js_composer/include/templates/shortcodes/vc_zigzag.php
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Class WPBakeryShortCode_Vc_Zigzag
 */
class WPBakeryShortCode_Vc_Zigzag extends WPBakeryShortCode {
}
