<?php

// Exit if accessed directly
defined('ABSPATH') || exit;

/**
 * WordPress Custom Post Type Based Log Entry Data Store
 *
 * @class RP_SUB_WP_Log_Entry_Data_Store
 * @package Subscriptio
 * @author RightPress
 */
abstract class RP_SUB_WP_Log_Entry_Data_Store extends RightPress_WP_Log_Entry_Data_Store
{




}
