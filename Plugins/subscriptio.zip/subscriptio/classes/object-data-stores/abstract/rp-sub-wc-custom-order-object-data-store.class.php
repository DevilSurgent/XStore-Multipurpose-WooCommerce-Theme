<?php

// Exit if accessed directly
defined('ABSPATH') || exit;

/**
 * WooCommerce Custom Order Object Data Store
 *
 * @class RP_SUB_WC_Custom_Order_Object_Data_Store
 * @package Subscriptio
 * @author RightPress
 */
abstract class RP_SUB_WC_Custom_Order_Object_Data_Store extends RightPress_WC_Custom_Order_Object_Data_Store
{





}
