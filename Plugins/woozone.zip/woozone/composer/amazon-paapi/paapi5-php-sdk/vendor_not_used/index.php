<?php die; ?>
this folder is not used anymore! keep it for a while (for some plugin versions updates) to make sure everything it's fine!