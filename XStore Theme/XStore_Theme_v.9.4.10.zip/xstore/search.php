<?php
/**
 * Template Name: Search results page
 * @xstore-version 9.4.0
 */

defined( 'ABSPATH' ) || exit( 'Direct script access denied.' );

get_template_part('index');